/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.crudjava;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author JEAN
 */
public class empleados {
    
    int dbId;
    int identificacion;
    String nombre;
    String cargo;
    
    public int getDbId() {
        return dbId;
    }

    public void setDbId(int dbId) {
        this.dbId = dbId;
    }

    public int getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(int identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    public void InsertarEmpleado(JTextField identificacion, JTextField nombre, JTextField cargo) {
    try {
        String textoIdentificacion = identificacion.getText();
        int identificacionEntero = Integer.parseInt(textoIdentificacion);
        setIdentificacion(identificacionEntero);
        setNombre(nombre.getText());
        setCargo(cargo.getText());
        
        conexion objetoConexion = new conexion();
        String consulta = "insert into empleados (identificacion, nombre, rol) values (?,?,?);";
        
        try {
            CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
            cs.setInt(1, getIdentificacion());
            cs.setString(2, getNombre());
            cs.setString(3, getCargo());
            
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Registrado correctamente");
            
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo Registrar");
        }
        
    } catch (NumberFormatException e) {
        System.out.println("Error: Verifica los datos de los campos.." + e.toString());
    }
    }
    public void MostrarEmpleados (JTable tablaEmpleados) {
        conexion objetoConexion = new conexion();
        
        DefaultTableModel modelo = new DefaultTableModel();
        TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<TableModel>(modelo);
        tablaEmpleados.setRowSorter(ordenarTabla);
        
        String sql="";
        
        modelo.addColumn("DB-ID");
        modelo.addColumn("Identificacion");
        modelo.addColumn("Nombre");
        modelo.addColumn("Rol/Cargo");
        
        tablaEmpleados.setModel(modelo);
        
        sql = "select * from empleados;";
        
        String[] datos = new String[4];
        Statement st;
        
        try {
            st = objetoConexion.establecerConexion().createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while (rs.next()) {
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                
                modelo.addRow(datos);
            }
            tablaEmpleados.setModel(modelo);
            
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: No se pudo mostrar los datos..");
        }    
    }
    public void seleccionar(JTable tablaEmpleados, JTextField dbId, JTextField identificacion, JTextField nombre, JTextField cargo) {
        try {
            int fila = tablaEmpleados.getSelectedRow();
            
            if (fila >= 0) {
                dbId.setText(tablaEmpleados.getValueAt(fila, 0).toString());
                identificacion.setText(tablaEmpleados.getValueAt(fila, 1).toString());
                nombre.setText(tablaEmpleados.getValueAt(fila, 2).toString());
                cargo.setText(tablaEmpleados.getValueAt(fila, 3).toString()); 
            }else {
                JOptionPane.showMessageDialog(null, "Error: Fila no seleccionada");
            }
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: No se ha podido seleccionar");
        }
    }
    
    public void Modificar(JTextField dbId, JTextField identificacion, JTextField nombre, JTextField cargo) {
        setDbId(Integer.parseInt(dbId.getText()));
        setIdentificacion(Integer.parseInt(identificacion.getText()));
        setNombre(nombre.getText());
        setCargo(cargo.getText());
        
        conexion objConexion = new conexion();
        
        String consulta = "update empleados set identificacion=?, nombre=?, rol=? where id=?;";
    
        try {
            CallableStatement cs = objConexion.establecerConexion().prepareCall(consulta);
            cs.setInt(1, getIdentificacion());
            cs.setString(2, getNombre());
            cs.setString(3, getCargo());
            cs.setInt(4, getDbId());
            
            cs.execute();
            JOptionPane.showMessageDialog(null, "Se modifico correctamente");
            
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo modificar.." + e.toString());
        }
    }
    
    public void Eliminar (JTextField dbId) {
        setDbId(Integer.parseInt(dbId.getText()));
        
        conexion objConexion = new conexion();
        
        String consulta = "delete from empleados where id=?;";
        
        try {
            CallableStatement cs = objConexion.establecerConexion().prepareCall(consulta);
            cs.setInt(1, getDbId());
            
            cs.execute();
            JOptionPane.showMessageDialog(null, "Se ha eliminado correctamente");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar" + e.toString());
        }
    }
}
