/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.crudjava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author JEAN
 */
public class conexion {
    Connection conectar = null;
    String usuario = "root";
    String contrasena = "mySQLpersonal#001";
    String dbNombre = "dbempleados";
    String ip = "localhost";
    String puerto = "3306";
    String url = "jdbc:mysql://"+ip+":"+puerto+"/"+dbNombre;
    
    public Connection establecerConexion() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conectar = DriverManager.getConnection(url, usuario, contrasena); 
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se establecio la conexion"+ e.toString());
        }
        return conectar;
    }
    
}
