/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.crudjava;

/**
 *
 * @author JEAN
 */
public class Crudjava {
    public static void main(String[] args) {
        appInterface objetoForm = new appInterface();
        objetoForm.setVisible(true);
    }
}
